# ReproPatch caa7d7a93330440dba28689185a129a1

任务：negative-maximum-demo-recovery
入口：verify-patch
结局：**REJECTED**
原因：REGRESSION\_FAILED
执行引擎：none
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：10.384 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：73

外部来源标签（未认证）：runtime-evidence-20261106

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/ddbaea40f9614ea59030510891e0efa5/34d64382869945b1b2ab60c6dca4f00a.xml |
| baseline | positive\_values | 通过 | evidence/ddbaea40f9614ea59030510891e0efa5/5a5187ce0d554b6493cae7eac5ce7786.xml |
| baseline | empty\_values | 通过 | evidence/ddbaea40f9614ea59030510891e0efa5/654d52ecca11453b8cc376e2351d1cc8.xml |
| baseline | mixed\_values | 通过 | evidence/ddbaea40f9614ea59030510891e0efa5/b25cf51c28c844f68819c0548d9c322d.xml |
| independent | negative\_values | 通过 | evidence/0581ef82bfa141b9bc937fc1824087fd/cc86bdc1cfa44ab5956815ddb3e4e5af.xml |
| independent | positive\_values | 通过 | evidence/0581ef82bfa141b9bc937fc1824087fd/60af18a688fe454b8f725240f2daaebf.xml |
| independent | empty\_values | 失败 | evidence/0581ef82bfa141b9bc937fc1824087fd/a416018aa4d742a49e802d956ecf0373.xml |
| independent | mixed\_values | 通过 | evidence/0581ef82bfa141b9bc937fc1824087fd/3ece542f175045bbad10587da25ba17d.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/b4168183263645428d07ca36082c8a13/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/9afd9182ccbc452794ed4e7ea178e09d/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/fd4ebdfc638649c68ff7846a13827e99/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/4fd965e8ff0048a89e9a94e6ffb165a5/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/519bb6df89f349cdbb9364cf64d69bed/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-34d64382869945b1b2ab60c6dca4f00a.xml --timeout 120.000000 | exited | 8 | logs/53dd73eb8b8148d2af12d18e93a267de/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-34d64382869945b1b2ab60c6dca4f00a.xml | exited | 0 | logs/8236f2373c3f420ca4192cd48d6c223f/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-5a5187ce0d554b6493cae7eac5ce7786.xml --timeout 120.000000 | exited | 0 | logs/b8e3cb4e0e9b4ab5aede9ad33e25cf68/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-5a5187ce0d554b6493cae7eac5ce7786.xml | exited | 0 | logs/50a35ba6deab466e80b0448402acdb88/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-654d52ecca11453b8cc376e2351d1cc8.xml --timeout 120.000000 | exited | 0 | logs/b04094fa1d484a409586c2ad241d6b9a/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-654d52ecca11453b8cc376e2351d1cc8.xml | exited | 0 | logs/97db16cf0dcd40dd98552a2569cae469/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-b25cf51c28c844f68819c0548d9c322d.xml --timeout 120.000000 | exited | 0 | logs/2d5ea79976584fa990703d77df6f3cb1/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/ddbaea40f9614ea59030510891e0efa5-b25cf51c28c844f68819c0548d9c322d.xml | exited | 0 | logs/51e90a0b02ae46efb517cf9e24c20a0b/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/83c0868be9e94b7a8ab9e96dec43e787/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/a1e354b22b48484885b1c9e931b009e0/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/df33af97368d42f6b64653d26b27211d/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/7903ead3b5434942b34c7008b9ded351/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/b4f9a26e67a04bd8a1cc9ab2b24939e6/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-cc86bdc1cfa44ab5956815ddb3e4e5af.xml --timeout 120.000000 | exited | 0 | logs/2b65b3f69eeb4a4fbb6ef5cd5443af13/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-cc86bdc1cfa44ab5956815ddb3e4e5af.xml | exited | 0 | logs/91121484a89d4c8b91ee9c47cce35d35/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-60af18a688fe454b8f725240f2daaebf.xml --timeout 120.000000 | exited | 0 | logs/1ab5fbed4b284af5bf80d51da2337123/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-60af18a688fe454b8f725240f2daaebf.xml | exited | 0 | logs/534afae3c02d48a092d994ab233e0459/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-a416018aa4d742a49e802d956ecf0373.xml --timeout 120.000000 | exited | 8 | logs/3c785b2364014eb6bd6e4ba5e2db0195/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-a416018aa4d742a49e802d956ecf0373.xml | exited | 0 | logs/bd74590b4f0347e9b212e9a298ba67ae/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-3ece542f175045bbad10587da25ba17d.xml --timeout 120.000000 | exited | 0 | logs/953f74a5ad8a4c67a11de88b18f8c0c6/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0581ef82bfa141b9bc937fc1824087fd-3ece542f175045bbad10587da25ba17d.xml | exited | 0 | logs/1cb90a13e3584015968b78136ab00808/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
