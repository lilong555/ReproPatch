# ReproPatch 17259e57b49442ff937f645c4a0f87b0

任务：negative-maximum-demo-recovery
入口：verify-patch
结局：**REJECTED**
原因：FORBIDDEN\_PATCH
执行引擎：none
模型：未知
Docker 隔离：未知
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：0.394 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：4

外部来源标签（未认证）：runtime-evidence-20261106

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |

错误：FORBIDDEN\_PATCH: 补丁修改了 protected 路径

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
