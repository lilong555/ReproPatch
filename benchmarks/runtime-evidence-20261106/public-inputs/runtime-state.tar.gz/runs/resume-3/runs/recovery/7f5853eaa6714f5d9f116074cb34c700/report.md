# ReproPatch 7f5853eaa6714f5d9f116074cb34c700

任务：negative-maximum-demo-recovery
入口：verify-patch
结局：**ACCEPTED**
原因：VERIFICATION\_PASSED
执行引擎：none
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：27.120 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：73

外部来源标签（未认证）：runtime-evidence-20261106

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/09ee921fd2cf46aebd40142b95a6038c/420592aac6de4dcca029d6343182ad26.xml |
| baseline | positive\_values | 通过 | evidence/09ee921fd2cf46aebd40142b95a6038c/80de3bd74f89418292707e88ef2715d3.xml |
| baseline | empty\_values | 通过 | evidence/09ee921fd2cf46aebd40142b95a6038c/a33d36da14f14c2ebf1e46d85be024c6.xml |
| baseline | mixed\_values | 通过 | evidence/09ee921fd2cf46aebd40142b95a6038c/262a9d0b68b647b695ea2908b583837d.xml |
| independent | negative\_values | 通过 | evidence/6840cfcedfc64bcd9b77e1aeb4f32727/e365fd2d1e9f414294e31ed84817d9d0.xml |
| independent | positive\_values | 通过 | evidence/6840cfcedfc64bcd9b77e1aeb4f32727/940df91154e042f59ffc8517120ef5a3.xml |
| independent | empty\_values | 通过 | evidence/6840cfcedfc64bcd9b77e1aeb4f32727/2bf82ba321274e2da982b8ade53c4945.xml |
| independent | mixed\_values | 通过 | evidence/6840cfcedfc64bcd9b77e1aeb4f32727/bdefb822e05d421fb6e82cd74edbef41.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/bd551ccb87174771841cc2fcd6b69df5/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/368d5760d1674d83b2dd130f36b9e467/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/632864f196c946138efebd56e895b6c1/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/ced0347d207d49a7a4536395f56781a5/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/0108e8e429364264809513fba40da608/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-420592aac6de4dcca029d6343182ad26.xml --timeout 120.000000 | exited | 8 | logs/31045bdff04c4ae8b4f0d1cf37e9798c/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-420592aac6de4dcca029d6343182ad26.xml | exited | 0 | logs/744aafc99e404af28a05d2c9c29508d4/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-80de3bd74f89418292707e88ef2715d3.xml --timeout 120.000000 | exited | 0 | logs/0880fa96bba441db8acefd7726bc5327/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-80de3bd74f89418292707e88ef2715d3.xml | exited | 0 | logs/1f4d5f1ee4a342eeb998c931502869a5/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-a33d36da14f14c2ebf1e46d85be024c6.xml --timeout 120.000000 | exited | 0 | logs/2170713ab1d045459f5b5d9355624373/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-a33d36da14f14c2ebf1e46d85be024c6.xml | exited | 0 | logs/c80d640fe9244139822f2ab6617f52e7/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-262a9d0b68b647b695ea2908b583837d.xml --timeout 120.000000 | exited | 0 | logs/6e1a39305c7348ce81063094cd2461c8/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/09ee921fd2cf46aebd40142b95a6038c-262a9d0b68b647b695ea2908b583837d.xml | exited | 0 | logs/ff6b775a6dab4c2b93d601cac0c79480/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/f7f467b286684497be4c37dcafc9997c/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/feb908c3ce004edba216e33a42f1e2a2/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/03d116479e6144fa90d6915ac18a310f/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/16a59ff771d343bbaf40244a88df3b38/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/435960e8c9134e91b76e2a7377b29aeb/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-e365fd2d1e9f414294e31ed84817d9d0.xml --timeout 120.000000 | exited | 0 | logs/6399454fbaa947a994dce25a42caed56/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-e365fd2d1e9f414294e31ed84817d9d0.xml | exited | 0 | logs/333e29b2e3be4c9eb7297cd3dd9dd456/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-940df91154e042f59ffc8517120ef5a3.xml --timeout 120.000000 | exited | 0 | logs/937d28a7526b4ea6aad14bb236e5df11/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-940df91154e042f59ffc8517120ef5a3.xml | exited | 0 | logs/7e891a60562743cc97274278c7e4be2c/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-2bf82ba321274e2da982b8ade53c4945.xml --timeout 120.000000 | exited | 0 | logs/42a42379aed94bccb3f211700ef4d7e4/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-2bf82ba321274e2da982b8ade53c4945.xml | exited | 0 | logs/4e9894b37bd44f70a5412e769bc7fc64/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-bdefb822e05d421fb6e82cd74edbef41.xml --timeout 120.000000 | exited | 0 | logs/613df552182b483284d85a3ce3092cbb/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6840cfcedfc64bcd9b77e1aeb4f32727-bdefb822e05d421fb6e82cd74edbef41.xml | exited | 0 | logs/0e03354deebf40f3812c7f097dadb20c/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
