# ReproPatch 6ca04c78f56d4d478400250f41262b02

任务：negative-maximum-demo-recovery
入口：run
结局：**ERROR**
原因：MODEL\_ERROR
执行引擎：fake
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：6.360 秒
模型步骤：4；准入工具：3
模型停止原因：MODEL\_ERROR
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：是；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：70


| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/2cb7570709854ee9b153332bda8813b0/9ba10f2673fa4f2a8c5cbf8b061c5384.xml |
| baseline | positive\_values | 通过 | evidence/2cb7570709854ee9b153332bda8813b0/606cfdfd893a41e0b015f94ebd75cbc7.xml |
| baseline | empty\_values | 通过 | evidence/2cb7570709854ee9b153332bda8813b0/202f372d0fac41bcb2ac4066480f3f31.xml |
| baseline | mixed\_values | 通过 | evidence/2cb7570709854ee9b153332bda8813b0/02e41ca051fa47eba104e75adc81b464.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/21ed58b489bd4901a6a2803bb191d6a0/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/094e58880d094cd18bd7129071d620bc/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/05a6a8775a524425a1638275b6386575/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/38e769df64cd4da29f87d768a1e1a3c2/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/42444e9571cf4cec8cf25baf5d59d56f/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-9ba10f2673fa4f2a8c5cbf8b061c5384.xml --timeout 120.000000 | exited | 8 | logs/790083663f6d430bb39f66616006dadf/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-9ba10f2673fa4f2a8c5cbf8b061c5384.xml | exited | 0 | logs/53bce120a72947e18c8c26961839c909/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-606cfdfd893a41e0b015f94ebd75cbc7.xml --timeout 120.000000 | exited | 0 | logs/bd9070927e7f40bfa9c1ae78c19a63a4/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-606cfdfd893a41e0b015f94ebd75cbc7.xml | exited | 0 | logs/544537bc684c4123aa01b86b5c5ce0c7/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-202f372d0fac41bcb2ac4066480f3f31.xml --timeout 120.000000 | exited | 0 | logs/aa763771e26b4d8888884be724a257b9/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-202f372d0fac41bcb2ac4066480f3f31.xml | exited | 0 | logs/256766f600f14ccc9671bfb19eec5df3/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-02e41ca051fa47eba104e75adc81b464.xml --timeout 120.000000 | exited | 0 | logs/df1328563e9c4c8aa8e74b7aea53fcc4/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/2cb7570709854ee9b153332bda8813b0-02e41ca051fa47eba104e75adc81b464.xml | exited | 0 | logs/d4556c4c4f614afc9ba07359109dca70/stderr.bin |

错误：MODEL\_ERROR: 模型执行失败
诊断附件：diagnostics/44034cc11e2a410fb6113ce040226dc6.txt
诊断附件：diagnostics/unverified.patch

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
模型生成不保证正确；通过 SDK 受控工具产生候选，最终结局由独立验证决定。
