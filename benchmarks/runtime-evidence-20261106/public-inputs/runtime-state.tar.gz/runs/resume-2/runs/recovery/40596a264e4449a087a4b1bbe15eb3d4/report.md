# ReproPatch 40596a264e4449a087a4b1bbe15eb3d4

任务：negative-maximum-demo-recovery
入口：run
结局：**ERROR**
原因：MODEL\_ERROR
执行引擎：fake
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：11.058 秒
模型步骤：4；准入工具：3
模型停止原因：MODEL\_ERROR
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：是；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：70


| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/0d22f03ffa5a40e098b3012fef1ec5df/ffd931cf4e39498799fb4e7e49f1b262.xml |
| baseline | positive\_values | 通过 | evidence/0d22f03ffa5a40e098b3012fef1ec5df/4af7a39d272649d2b0e789ace95b002f.xml |
| baseline | empty\_values | 通过 | evidence/0d22f03ffa5a40e098b3012fef1ec5df/354ed768bc9146fba50acaa330a57c72.xml |
| baseline | mixed\_values | 通过 | evidence/0d22f03ffa5a40e098b3012fef1ec5df/718fbc3a57cd494d83f5ecdadca17dc3.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/05cbf841d7ea461d9a1fc04ba22f8ba5/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/7189c741e72f45b6a2b85865b43569ed/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/a8836cc058b548fd812b885a01987e61/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/70723f2b07404a0a87304547fe79ec55/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/26f4d6bb7b83438aad0b014a1b2702c5/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-ffd931cf4e39498799fb4e7e49f1b262.xml --timeout 120.000000 | exited | 8 | logs/b5970776636d4c2db009bdcd394d444a/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-ffd931cf4e39498799fb4e7e49f1b262.xml | exited | 0 | logs/3c67bb2813df44eb9a2d6d9d85ff6663/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-4af7a39d272649d2b0e789ace95b002f.xml --timeout 120.000000 | exited | 0 | logs/9eaa7c1a0d2a4fd6bbe6fe057fa174e7/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-4af7a39d272649d2b0e789ace95b002f.xml | exited | 0 | logs/7880e66912dd4f6f804270e268b11b74/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-354ed768bc9146fba50acaa330a57c72.xml --timeout 120.000000 | exited | 0 | logs/3fe6f9b262514ada86e530b1813c2de6/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-354ed768bc9146fba50acaa330a57c72.xml | exited | 0 | logs/7e9db1029f844fa38a259e387cac43c5/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-718fbc3a57cd494d83f5ecdadca17dc3.xml --timeout 120.000000 | exited | 0 | logs/6899bfbd003b46039a3a1236a14432a6/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0d22f03ffa5a40e098b3012fef1ec5df-718fbc3a57cd494d83f5ecdadca17dc3.xml | exited | 0 | logs/62460d39927b47d6a583c9062d07b0e5/stderr.bin |

错误：MODEL\_ERROR: 模型执行失败
诊断附件：diagnostics/5abb03fbb72a40d19f482dcd2a4654dc.txt
诊断附件：diagnostics/unverified.patch

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
模型生成不保证正确；通过 SDK 受控工具产生候选，最终结局由独立验证决定。
