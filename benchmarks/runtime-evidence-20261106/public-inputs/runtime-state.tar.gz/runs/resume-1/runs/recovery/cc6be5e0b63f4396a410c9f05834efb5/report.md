# ReproPatch cc6be5e0b63f4396a410c9f05834efb5

任务：negative-maximum-demo-recovery
入口：run
结局：**ERROR**
原因：MODEL\_ERROR
执行引擎：fake
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：20.719 秒
模型步骤：4；准入工具：3
模型停止原因：MODEL\_ERROR
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：是；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：70


| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/0485cd2e078c46e0877afe0f5bb4708a/2761768337ad4369bab3988a3b741a01.xml |
| baseline | positive\_values | 通过 | evidence/0485cd2e078c46e0877afe0f5bb4708a/c924649812c54e6d99bacb3706784d01.xml |
| baseline | empty\_values | 通过 | evidence/0485cd2e078c46e0877afe0f5bb4708a/dc993c8e46e74bbd814d49044990bf6c.xml |
| baseline | mixed\_values | 通过 | evidence/0485cd2e078c46e0877afe0f5bb4708a/828050b9a18c4127bafe8ff910ca9057.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/59865c7c0bd04aaa8ef95c5a5a158012/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/8bf83cda2cba4cf7a316991fe50fdcfd/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/439799d5db6d4c0a8450b5da37346565/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/d77f981b4b3044f5aa33b78b295f7ca9/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/e2f26adab310444e8245e303fd3f3b5c/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-2761768337ad4369bab3988a3b741a01.xml --timeout 120.000000 | exited | 8 | logs/2b240eece053488caae1fc6ff60ccde1/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-2761768337ad4369bab3988a3b741a01.xml | exited | 0 | logs/50ecf338c57b4eed9a0e2c5aab06b57a/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-c924649812c54e6d99bacb3706784d01.xml --timeout 120.000000 | exited | 0 | logs/c102036a271746459e21917f7d703774/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-c924649812c54e6d99bacb3706784d01.xml | exited | 0 | logs/08773cc79a164fd5a0480ef28f3db3a7/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-dc993c8e46e74bbd814d49044990bf6c.xml --timeout 120.000000 | exited | 0 | logs/a62ad5f0d878456995d9d4e389848a80/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-dc993c8e46e74bbd814d49044990bf6c.xml | exited | 0 | logs/f0fa5bdcad674f85ac5364b3549028ff/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-828050b9a18c4127bafe8ff910ca9057.xml --timeout 120.000000 | exited | 0 | logs/941fbb38ee394194af4bc2f04aa7d94d/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/0485cd2e078c46e0877afe0f5bb4708a-828050b9a18c4127bafe8ff910ca9057.xml | exited | 0 | logs/14a3f3c4a5d248fb8be21508a6f00be5/stderr.bin |

错误：MODEL\_ERROR: 模型执行失败
诊断附件：diagnostics/dce0d7f3aae3436e9da8be199af136bb.txt
诊断附件：diagnostics/unverified.patch

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
模型生成不保证正确；通过 SDK 受控工具产生候选，最终结局由独立验证决定。
