# ReproPatch f63b2b300ec34d1da481d5893adf32b0

任务：negative-maximum-demo-recovery
入口：run
结局：**ACCEPTED**
原因：VERIFICATION\_PASSED
执行引擎：fake
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：20.788 秒
模型步骤：5；准入工具：4
模型停止原因：MODEL\_FINISHED
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：是；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：145


| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/6d482e80372d48ff92800ff3b22fd276/a176042fb1504a6996ce13a22b990aa1.xml |
| baseline | positive\_values | 通过 | evidence/6d482e80372d48ff92800ff3b22fd276/e14f164369cc4460b0b5e7a1ac94d570.xml |
| baseline | empty\_values | 通过 | evidence/6d482e80372d48ff92800ff3b22fd276/93505cfb165c44da838bdda2e03ff90d.xml |
| baseline | mixed\_values | 通过 | evidence/6d482e80372d48ff92800ff3b22fd276/71448079025142e08394fe4ab04b6a0d.xml |
| agent\_check | negative\_values | 通过 | evidence/b10e5e0c974040f5bd32a07955e088e3/946d8b4650ee40df860fe9ccad710206.xml |
| agent\_check | positive\_values | 通过 | evidence/b10e5e0c974040f5bd32a07955e088e3/c73c4e3108ae4a7cab710382a39cdb2a.xml |
| agent\_check | empty\_values | 通过 | evidence/b10e5e0c974040f5bd32a07955e088e3/0b7bbe525c8b40a5b76222e168114849.xml |
| agent\_check | mixed\_values | 通过 | evidence/b10e5e0c974040f5bd32a07955e088e3/a165949de7814b8eabef4a9651e1618e.xml |
| independent | negative\_values | 通过 | evidence/d3ba21816ca04b1996bb0790064ff869/201594389169495899a622bb61a1aede.xml |
| independent | positive\_values | 通过 | evidence/d3ba21816ca04b1996bb0790064ff869/0f4f67a0d43747d79e4f109112d7beb3.xml |
| independent | empty\_values | 通过 | evidence/d3ba21816ca04b1996bb0790064ff869/1f3d2f3387744aeaafa94cef559f3b8a.xml |
| independent | mixed\_values | 通过 | evidence/d3ba21816ca04b1996bb0790064ff869/3629fd54f6c24839a6c4e326edea9b19.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/1a0e8508558d43669f0b9b4cbbdab058/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/7efb364fd7ef40c5846d9a9d2e11e7d8/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/0e4d052231604c399228bf4086754d52/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/762676bd63174e059d8a59eb812b1a1d/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/10df798fecb04203874fdf3660a745cd/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-a176042fb1504a6996ce13a22b990aa1.xml --timeout 120.000000 | exited | 8 | logs/d0d0054c20ad4a09afb03210ada32aee/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-a176042fb1504a6996ce13a22b990aa1.xml | exited | 0 | logs/080878f1cb8c45b08bcd055b4d1011b3/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-e14f164369cc4460b0b5e7a1ac94d570.xml --timeout 120.000000 | exited | 0 | logs/67d75ebb1f4d43e195461c2149fb3780/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-e14f164369cc4460b0b5e7a1ac94d570.xml | exited | 0 | logs/7909fe9a8e704763b601fc2fa0156055/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-93505cfb165c44da838bdda2e03ff90d.xml --timeout 120.000000 | exited | 0 | logs/0215f461da514be1b9bd5ceaa3856c85/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-93505cfb165c44da838bdda2e03ff90d.xml | exited | 0 | logs/dcfc9ce77253492d8f543efc2312aed8/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-71448079025142e08394fe4ab04b6a0d.xml --timeout 120.000000 | exited | 0 | logs/9764243e13d34cfe99b35f160bd436e1/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/6d482e80372d48ff92800ff3b22fd276-71448079025142e08394fe4ab04b6a0d.xml | exited | 0 | logs/6bc8dfefd75c4b9ba8347a7612e965c9/stderr.bin |
| agent\_check | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/98406a1434694ee7843d486998071ca8/stderr.bin |
| agent\_check | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/d158f9b887304cc4ab66b901e598f8d1/stderr.bin |
| agent\_check | cmake --build /build --parallel 2 | exited | 0 | logs/369c938cd3e5431e90f38d420789e4ec/stderr.bin |
| agent\_check | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/ec771834cb6e4206a27b3924815b511d/stderr.bin |
| agent\_check | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/5943bcc344a34e4ea5847a800bf3c732/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-946d8b4650ee40df860fe9ccad710206.xml --timeout 120.000000 | exited | 0 | logs/88c10613633b4abeb73e2a6c672b2304/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-946d8b4650ee40df860fe9ccad710206.xml | exited | 0 | logs/dc4a9ffaa81440159e08c455e355aa70/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-c73c4e3108ae4a7cab710382a39cdb2a.xml --timeout 120.000000 | exited | 0 | logs/1b7d64b392944057abb7ba84ad788ef7/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-c73c4e3108ae4a7cab710382a39cdb2a.xml | exited | 0 | logs/0b03801aec5443de8ec3939683f1c9c1/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-0b7bbe525c8b40a5b76222e168114849.xml --timeout 120.000000 | exited | 0 | logs/c70505fb95594126bb2a9cfd3abef77a/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-0b7bbe525c8b40a5b76222e168114849.xml | exited | 0 | logs/3385be7b509f47129c00102d89221973/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-a165949de7814b8eabef4a9651e1618e.xml --timeout 120.000000 | exited | 0 | logs/bae93b4c8b0747188c88d6d2ef8debf4/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b10e5e0c974040f5bd32a07955e088e3-a165949de7814b8eabef4a9651e1618e.xml | exited | 0 | logs/879c0563881c40c79cbe349a0dc35d46/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/007212f8c7b64ed8ad229fc1f954e497/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/fd0173d522d8433c8ba2f15b8d432c83/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/374806c7367c4b7b806fc38f5f3b6d9f/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/c710f2f6cb7e4f829283faefb2020916/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/5621d3bacf0d4b65bc35f0b8c1e00155/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-201594389169495899a622bb61a1aede.xml --timeout 120.000000 | exited | 0 | logs/077dad0621174efa9bba9e8dd997716f/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-201594389169495899a622bb61a1aede.xml | exited | 0 | logs/96b0e903324c494baec04b8320033d82/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-0f4f67a0d43747d79e4f109112d7beb3.xml --timeout 120.000000 | exited | 0 | logs/8aa920b9aa38448da1447668d2776ee2/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-0f4f67a0d43747d79e4f109112d7beb3.xml | exited | 0 | logs/d5ef1fe363c44b6f95926a769d757b0c/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-1f3d2f3387744aeaafa94cef559f3b8a.xml --timeout 120.000000 | exited | 0 | logs/0f925808b34d4e8d9c36e7f7e66eb219/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-1f3d2f3387744aeaafa94cef559f3b8a.xml | exited | 0 | logs/dc627f9db7f74b7abb7cb4e814439581/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-3629fd54f6c24839a6c4e326edea9b19.xml --timeout 120.000000 | exited | 0 | logs/099cc75be92e4d329e5a340b24c3dcf3/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d3ba21816ca04b1996bb0790064ff869-3629fd54f6c24839a6c4e326edea9b19.xml | exited | 0 | logs/1de27f03146944d6a38ae6fd754d3dca/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
模型生成不保证正确；通过 SDK 受控工具产生候选，最终结局由独立验证决定。
