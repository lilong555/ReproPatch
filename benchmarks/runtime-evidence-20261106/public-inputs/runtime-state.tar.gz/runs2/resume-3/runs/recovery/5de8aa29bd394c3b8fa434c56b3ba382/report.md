# ReproPatch 5de8aa29bd394c3b8fa434c56b3ba382

任务：negative-maximum-demo-recovery
入口：run
结局：**ACCEPTED**
原因：VERIFICATION\_PASSED
执行引擎：fake
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：30.206 秒
模型步骤：5；准入工具：4
模型停止原因：MODEL\_FINISHED
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：是；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：145


| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/f62d40942a134412bf99767ff0fff236/a11a82d4b31d4caeb9bbfe665e0e6e4d.xml |
| baseline | positive\_values | 通过 | evidence/f62d40942a134412bf99767ff0fff236/cb27e4ad495d4329a0ca2c92be0edea6.xml |
| baseline | empty\_values | 通过 | evidence/f62d40942a134412bf99767ff0fff236/cbbebc35c6d04983adb560d54aad774e.xml |
| baseline | mixed\_values | 通过 | evidence/f62d40942a134412bf99767ff0fff236/cf043b0436064f33bb5dee5b220f13d0.xml |
| agent\_check | negative\_values | 通过 | evidence/b1d2f8c0acac431f9e33c2a31cb2599e/24a014fa554041518babeb04b9e90cf1.xml |
| agent\_check | positive\_values | 通过 | evidence/b1d2f8c0acac431f9e33c2a31cb2599e/2dd0a06810aa48d68a65ae6bd5ec76ed.xml |
| agent\_check | empty\_values | 通过 | evidence/b1d2f8c0acac431f9e33c2a31cb2599e/79efe2cc95624303bdd0a856aa97c70d.xml |
| agent\_check | mixed\_values | 通过 | evidence/b1d2f8c0acac431f9e33c2a31cb2599e/60047b081b8045b3af803b74ae72e63a.xml |
| independent | negative\_values | 通过 | evidence/5cce223b411d44e5a6e44696fa139c32/62334e6765bb401ebd588e36858a30ee.xml |
| independent | positive\_values | 通过 | evidence/5cce223b411d44e5a6e44696fa139c32/de6c3db95c0e4c62a0b010adc4c89210.xml |
| independent | empty\_values | 通过 | evidence/5cce223b411d44e5a6e44696fa139c32/a51df185e5e34e178ac73e7c2ada1366.xml |
| independent | mixed\_values | 通过 | evidence/5cce223b411d44e5a6e44696fa139c32/70bf61ef2c31420fbfe1cd44fbd673e4.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/6d92e6c6692d4c6ab015759a661285ef/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/a42077d68c3c432d8032421886fcd140/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/eb190947a4524573ba3338e993fad029/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/af0d4004d4704a1c89a53c351408781d/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/e97cbf7bfd2d4025b4d3f8bd2cebb5f6/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-a11a82d4b31d4caeb9bbfe665e0e6e4d.xml --timeout 120.000000 | exited | 8 | logs/ef544f5e84364525b11d3534f525dc03/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-a11a82d4b31d4caeb9bbfe665e0e6e4d.xml | exited | 0 | logs/c33a3b33300a4f3cba21f54fe547367c/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-cb27e4ad495d4329a0ca2c92be0edea6.xml --timeout 120.000000 | exited | 0 | logs/81158b11d49f49fabb5041da015e6d7e/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-cb27e4ad495d4329a0ca2c92be0edea6.xml | exited | 0 | logs/6898758845404ccb9d36056e9acfb7ce/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-cbbebc35c6d04983adb560d54aad774e.xml --timeout 120.000000 | exited | 0 | logs/0aaf813b6ace4794909a49d5978da11a/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-cbbebc35c6d04983adb560d54aad774e.xml | exited | 0 | logs/fd166d8997bd4e6dbcb4a1efed939d74/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-cf043b0436064f33bb5dee5b220f13d0.xml --timeout 120.000000 | exited | 0 | logs/a3d6dfcffafe448aa977bfe5007bc36e/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/f62d40942a134412bf99767ff0fff236-cf043b0436064f33bb5dee5b220f13d0.xml | exited | 0 | logs/7a1807ba24a54d27a5140bc683fd0787/stderr.bin |
| agent\_check | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/b5487c65bb7b448d8ea012cec29b41e6/stderr.bin |
| agent\_check | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/cf417f7b499347a2916857e49bda9210/stderr.bin |
| agent\_check | cmake --build /build --parallel 2 | exited | 0 | logs/2e662722fdb04ab7814930f2f6fa4e00/stderr.bin |
| agent\_check | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/f4f37cf183174684a1580a954af5a35f/stderr.bin |
| agent\_check | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/b7913c9c893644c097b32eb3ce4fc155/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-24a014fa554041518babeb04b9e90cf1.xml --timeout 120.000000 | exited | 0 | logs/7c5b5ba6c9a34fa28b2878ddf8d45527/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-24a014fa554041518babeb04b9e90cf1.xml | exited | 0 | logs/14e8d579595147e19b9616b7f0aea25b/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-2dd0a06810aa48d68a65ae6bd5ec76ed.xml --timeout 120.000000 | exited | 0 | logs/6d14a30b6b9348cabdbac0edffe599f7/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-2dd0a06810aa48d68a65ae6bd5ec76ed.xml | exited | 0 | logs/323f11b9246a44748ee7df09610d5aec/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-79efe2cc95624303bdd0a856aa97c70d.xml --timeout 120.000000 | exited | 0 | logs/51213a253b8347e890f2317f9cf0c9bd/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-79efe2cc95624303bdd0a856aa97c70d.xml | exited | 0 | logs/e618828878054014ac32070d5fa9d75d/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-60047b081b8045b3af803b74ae72e63a.xml --timeout 120.000000 | exited | 0 | logs/7ae67616c0e94bc694b6592833d68800/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/b1d2f8c0acac431f9e33c2a31cb2599e-60047b081b8045b3af803b74ae72e63a.xml | exited | 0 | logs/6f95613cc1ef4a0a92c8f2ccaa9a2c8e/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/22793297e509427ca11b4425ea182be8/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/1f4fd7a5f88f41b89be309e72f1d29d8/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/d4c3167f4cd348f0919b86e35b31dddb/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/67cd829584584be1a129ac9c0cb4778b/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/94dd24159b484987944ec7f60abef8a8/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-62334e6765bb401ebd588e36858a30ee.xml --timeout 120.000000 | exited | 0 | logs/f6c9176393c64c00b12b762e7cccc568/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-62334e6765bb401ebd588e36858a30ee.xml | exited | 0 | logs/ee0863fd9c864500b79e65b7d70aa226/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-de6c3db95c0e4c62a0b010adc4c89210.xml --timeout 120.000000 | exited | 0 | logs/5515114c2c534abcb1589eb6e695e29b/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-de6c3db95c0e4c62a0b010adc4c89210.xml | exited | 0 | logs/302389911e1e48449a7ae4525458d275/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-a51df185e5e34e178ac73e7c2ada1366.xml --timeout 120.000000 | exited | 0 | logs/3fdb0075371b463d81858219ed482159/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-a51df185e5e34e178ac73e7c2ada1366.xml | exited | 0 | logs/b86dfdabd0f44e81be3fa8482188c9f2/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-70bf61ef2c31420fbfe1cd44fbd673e4.xml --timeout 120.000000 | exited | 0 | logs/ed9000c28ddb4ea79d5f83c0db997432/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cce223b411d44e5a6e44696fa139c32-70bf61ef2c31420fbfe1cd44fbd673e4.xml | exited | 0 | logs/037397f468eb462287e0c0b381a2ea45/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
模型生成不保证正确；通过 SDK 受控工具产生候选，最终结局由独立验证决定。
