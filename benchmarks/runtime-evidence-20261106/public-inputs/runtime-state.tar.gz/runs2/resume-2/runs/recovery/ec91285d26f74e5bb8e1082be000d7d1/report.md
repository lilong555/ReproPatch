# ReproPatch ec91285d26f74e5bb8e1082be000d7d1

任务：negative-maximum-demo-recovery
入口：run
结局：**ACCEPTED**
原因：VERIFICATION\_PASSED
执行引擎：fake
模型：未知
Docker 隔离：是
基线 commit：a98a31601ab70499baae3a2a254959d16b72f485
镜像：sha256:c72159ee43e25d6f43b25224e08622ba4f9708809354236f80b64e020d0c0a6d
耗时：30.771 秒
模型步骤：5；准入工具：4
模型停止原因：MODEL\_FINISHED
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：是；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：145


| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/7fc300d1042b4ccd967f257ea8098b00/bc3d14305ce24728836cabbdaa3b3ede.xml |
| baseline | positive\_values | 通过 | evidence/7fc300d1042b4ccd967f257ea8098b00/4887328a37844a2f8b30b4975ce94e64.xml |
| baseline | empty\_values | 通过 | evidence/7fc300d1042b4ccd967f257ea8098b00/f9555d9db0184003967b109667946e7f.xml |
| baseline | mixed\_values | 通过 | evidence/7fc300d1042b4ccd967f257ea8098b00/b695fcd7b25442dcb4ec9520fe52d27c.xml |
| agent\_check | negative\_values | 通过 | evidence/c356d70f31d34a53a08422433ea2a73b/a972e212e24f4d6085a564aee45405b3.xml |
| agent\_check | positive\_values | 通过 | evidence/c356d70f31d34a53a08422433ea2a73b/d2b36aaa17474b0591c36ad42ad4975b.xml |
| agent\_check | empty\_values | 通过 | evidence/c356d70f31d34a53a08422433ea2a73b/f9afd7c3a1e84673b5e33f99c1da21f1.xml |
| agent\_check | mixed\_values | 通过 | evidence/c356d70f31d34a53a08422433ea2a73b/f3a1b6ac91354965adca653ac0b00b34.xml |
| independent | negative\_values | 通过 | evidence/d8523e97c6ea4646ac95ed6e08a2b374/f3835e1b82864a38915c24f2eb284465.xml |
| independent | positive\_values | 通过 | evidence/d8523e97c6ea4646ac95ed6e08a2b374/4943ed06183b43a1aa2ccb7a01b8b1ae.xml |
| independent | empty\_values | 通过 | evidence/d8523e97c6ea4646ac95ed6e08a2b374/96c59ed45ac94291af20028edd29744b.xml |
| independent | mixed\_values | 通过 | evidence/d8523e97c6ea4646ac95ed6e08a2b374/4a6f3a0e34b547beaa58d0ea31bd10a3.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/375a10c3b31c4097bb6f00fe67ef621e/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/28550e4a66934096aab5ce54585bf959/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/bc261c5bfab746e18a3dbd8994a0c891/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/d82ff4c6a1a84972b3858d4bc465522e/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/d3e1ce454455478caaae6059caadb2ef/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-bc3d14305ce24728836cabbdaa3b3ede.xml --timeout 120.000000 | exited | 8 | logs/91cf3f1270d4487cbf9c76b0bca3fa39/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-bc3d14305ce24728836cabbdaa3b3ede.xml | exited | 0 | logs/460e3bb32ab94a17a651a1cf96ee61b7/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-4887328a37844a2f8b30b4975ce94e64.xml --timeout 120.000000 | exited | 0 | logs/b0b86ba65cf04009b5fb0dfc2b37c289/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-4887328a37844a2f8b30b4975ce94e64.xml | exited | 0 | logs/8f956f542bdb415d84d1d7f245c93bfb/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-f9555d9db0184003967b109667946e7f.xml --timeout 120.000000 | exited | 0 | logs/05ca5bbe6b764e28b13ac2dfb457f7c2/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-f9555d9db0184003967b109667946e7f.xml | exited | 0 | logs/7854e11ac3f5456c93aa0e2a35d30e2f/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-b695fcd7b25442dcb4ec9520fe52d27c.xml --timeout 120.000000 | exited | 0 | logs/7bfac144da204ad7b74d35d736cb1a5b/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/7fc300d1042b4ccd967f257ea8098b00-b695fcd7b25442dcb4ec9520fe52d27c.xml | exited | 0 | logs/3f77f9ab777a41f280e6eaee15e399af/stderr.bin |
| agent\_check | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/b54fce20538543f897f8b4ce0d0b0612/stderr.bin |
| agent\_check | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/8ec46676ef5c41a18e346fb1b5ce8f37/stderr.bin |
| agent\_check | cmake --build /build --parallel 2 | exited | 0 | logs/b7399e9e4cf64a7c8eb62fd510afc7c5/stderr.bin |
| agent\_check | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/df8c260b649c4cbfbdbc7513489944f3/stderr.bin |
| agent\_check | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/3ec9d522460a46cfaeb484d0b8791164/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-a972e212e24f4d6085a564aee45405b3.xml --timeout 120.000000 | exited | 0 | logs/80d2b5226aae498b93b5f20f7f294fd7/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-a972e212e24f4d6085a564aee45405b3.xml | exited | 0 | logs/7da13d9657ee433a823038206248b145/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-d2b36aaa17474b0591c36ad42ad4975b.xml --timeout 120.000000 | exited | 0 | logs/4b954781ddcf4ca09b59b35b418b3a78/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-d2b36aaa17474b0591c36ad42ad4975b.xml | exited | 0 | logs/5da1b718d51f4bada75e5938bb0029d0/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-f9afd7c3a1e84673b5e33f99c1da21f1.xml --timeout 120.000000 | exited | 0 | logs/8ebe96fdd9e647d7a4b28212d8008d70/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-f9afd7c3a1e84673b5e33f99c1da21f1.xml | exited | 0 | logs/244d0406aad643fc9a93184b8bcd3ae6/stderr.bin |
| agent\_check | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-f3a1b6ac91354965adca653ac0b00b34.xml --timeout 120.000000 | exited | 0 | logs/5fdef53b07794750932e4adffc1a7838/stderr.bin |
| agent\_check | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/c356d70f31d34a53a08422433ea2a73b-f3a1b6ac91354965adca653ac0b00b34.xml | exited | 0 | logs/90cdc1acffba4f44acd6556bf64fea8b/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/10af67c4501e4259903a9ac3f7dc52fe/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/35238225d807419bab0ff10bd304150b/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/05f3ab8de11e46f0ae540e7287092518/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/1db7e6f70cad450c810c798fb0546ebc/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/13f925163f244b8c872ebc1e8859b015/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-f3835e1b82864a38915c24f2eb284465.xml --timeout 120.000000 | exited | 0 | logs/ea1f9e771575405a946f63f553f9fb7a/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-f3835e1b82864a38915c24f2eb284465.xml | exited | 0 | logs/5ec60d420fcb46f38d1991f216bf3001/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-4943ed06183b43a1aa2ccb7a01b8b1ae.xml --timeout 120.000000 | exited | 0 | logs/133f547ffc14433381dc46bc339f6d8a/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-4943ed06183b43a1aa2ccb7a01b8b1ae.xml | exited | 0 | logs/4c11680f4a174733beea8e10ca3817e2/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-96c59ed45ac94291af20028edd29744b.xml --timeout 120.000000 | exited | 0 | logs/1b4e692de64845c484991f8abdda0af6/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-96c59ed45ac94291af20028edd29744b.xml | exited | 0 | logs/699cb88b4be04840ad72a3747e1ed0d9/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-4a6f3a0e34b547beaa58d0ea31bd10a3.xml --timeout 120.000000 | exited | 0 | logs/ae3199aaf19f4f75a2fc23373fc22f49/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d8523e97c6ea4646ac95ed6e08a2b374-4a6f3a0e34b547beaa58d0ea31bd10a3.xml | exited | 0 | logs/29e3e38cab21409fad219ef7d86a47e5/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
模型生成不保证正确；通过 SDK 受控工具产生候选，最终结局由独立验证决定。
