# ReproPatch 0a47d35fd4ef4bc5b4d42e30f957adf1

任务：stale-build-injection
入口：verify-patch
结局：**REJECTED**
原因：REGRESSION\_FAILED
执行引擎：none
模型：未知
Docker 隔离：是
基线 commit：59f31d6d29d0fc51eaeb08bf46e757c65022932e
镜像：sha256:500d13919a823b0673d645dfd22b242d6b4bf1069fab2b4efade2a5a27de2e41
耗时：8.116 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：73

外部来源标签（未认证）：stale-build-injection

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/14d22eb9aabc46898c566ff4ac45dfa0/0d426563fd734db1a4f916951cf212ff.xml |
| baseline | positive\_values | 通过 | evidence/14d22eb9aabc46898c566ff4ac45dfa0/9b52e626dffe49b6a06c174713ff1437.xml |
| baseline | empty\_values | 通过 | evidence/14d22eb9aabc46898c566ff4ac45dfa0/0113644707c14f0095b753cad8c533c6.xml |
| baseline | mixed\_values | 通过 | evidence/14d22eb9aabc46898c566ff4ac45dfa0/e4f1170b81704f189914e2f23c843f4f.xml |
| independent | negative\_values | 通过 | evidence/d1a24a470e754f61914e73cae1afb6cd/66410bce3af04905afbbe99070038001.xml |
| independent | positive\_values | 通过 | evidence/d1a24a470e754f61914e73cae1afb6cd/ddcb8a2892f8413fbb2c9575467abe0f.xml |
| independent | empty\_values | 失败 | evidence/d1a24a470e754f61914e73cae1afb6cd/3aae4da928934acea3c095b5ea503a4b.xml |
| independent | mixed\_values | 通过 | evidence/d1a24a470e754f61914e73cae1afb6cd/61afd28a79f741e58378d91883d6ba4f.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/0f4d3ad786fc4865ad31836a73d6a6c2/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/27fd87dd07504660add22925ab981734/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/3fbdd381fde04a12ae6225f365414942/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/2145088d2a8d4d57bc4106a42c3f059e/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/00f6c1487ba9468880ea30049e2569bc/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-0d426563fd734db1a4f916951cf212ff.xml --timeout 120.000000 | exited | 8 | logs/6bbf1b98c94a4a70b904464aea6ebc85/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-0d426563fd734db1a4f916951cf212ff.xml | exited | 0 | logs/d6b0eaf83aa14e2098bc1a2978c88d66/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-9b52e626dffe49b6a06c174713ff1437.xml --timeout 120.000000 | exited | 0 | logs/e6dcd71c293b45f89f1ba6b1720982a5/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-9b52e626dffe49b6a06c174713ff1437.xml | exited | 0 | logs/f133c6c87d47413d96b79e8402b2807e/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-0113644707c14f0095b753cad8c533c6.xml --timeout 120.000000 | exited | 0 | logs/39f8e58f614c40b08c8bf1989c47a4fe/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-0113644707c14f0095b753cad8c533c6.xml | exited | 0 | logs/e0e6309b6018490b880e3186bafd9756/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-e4f1170b81704f189914e2f23c843f4f.xml --timeout 120.000000 | exited | 0 | logs/dbdc5ca9835747d6b0850b7a13622196/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/14d22eb9aabc46898c566ff4ac45dfa0-e4f1170b81704f189914e2f23c843f4f.xml | exited | 0 | logs/2d3a5d9c2cbb46f28a3b5271ff3439f4/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/683df1f53bea4dcfadddc27d8fcb4c29/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/4d86aea61d654ca2af502cfb7a7be7fc/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/6b8291fade1e4208a4fef1e5709e58e1/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/d2ede4329969404b9f97e2345eee5eb7/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/7d83a85bff3246db8faf3897bf956f85/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-66410bce3af04905afbbe99070038001.xml --timeout 120.000000 | exited | 0 | logs/ed9a1b36433c430faa0e22bdde93ae49/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-66410bce3af04905afbbe99070038001.xml | exited | 0 | logs/3fd02673378b41f0851d1d4796bd35fc/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-ddcb8a2892f8413fbb2c9575467abe0f.xml --timeout 120.000000 | exited | 0 | logs/92c21e9ff35d41eea0c605952687946e/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-ddcb8a2892f8413fbb2c9575467abe0f.xml | exited | 0 | logs/26b35d8251d64cd192e3c7021d143b62/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-3aae4da928934acea3c095b5ea503a4b.xml --timeout 120.000000 | exited | 8 | logs/32c0cd2b0cb84be79297edf9130ac22c/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-3aae4da928934acea3c095b5ea503a4b.xml | exited | 0 | logs/01ab7badd64c420baf80fd6d96a7153f/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-61afd28a79f741e58378d91883d6ba4f.xml --timeout 120.000000 | exited | 0 | logs/16155675a1e24a588cfc9e6555236dbc/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/d1a24a470e754f61914e73cae1afb6cd-61afd28a79f741e58378d91883d6ba4f.xml | exited | 0 | logs/f7f4f2b6760641d284d4659d5d5605a4/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
