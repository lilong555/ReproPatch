# ReproPatch f76eda9819184da7b93fef9ff93d3cd4

任务：stale-build-injection
入口：verify-patch
结局：**REJECTED**
原因：REGRESSION\_FAILED
执行引擎：none
模型：未知
Docker 隔离：是
基线 commit：59f31d6d29d0fc51eaeb08bf46e757c65022932e
镜像：sha256:500d13919a823b0673d645dfd22b242d6b4bf1069fab2b4efade2a5a27de2e41
耗时：8.049 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：73

外部来源标签（未认证）：stale-build-injection

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/caba0dda00be4109a575f8426a7ccf53/a0b80d7817204b8e9e0f69fd5614022d.xml |
| baseline | positive\_values | 通过 | evidence/caba0dda00be4109a575f8426a7ccf53/5d5905fb2d74482994cdc7992364286c.xml |
| baseline | empty\_values | 通过 | evidence/caba0dda00be4109a575f8426a7ccf53/5b7014be52834d34b3c30e896bc774f2.xml |
| baseline | mixed\_values | 通过 | evidence/caba0dda00be4109a575f8426a7ccf53/89594a560bf04f07949838114f92411f.xml |
| independent | negative\_values | 通过 | evidence/538ece5cbc85437183c97093bbd60dab/30a0ffa345c049a0b33126edd1c3bb91.xml |
| independent | positive\_values | 通过 | evidence/538ece5cbc85437183c97093bbd60dab/6249c164fb2d48dea7f89b9aeb6320b5.xml |
| independent | empty\_values | 失败 | evidence/538ece5cbc85437183c97093bbd60dab/f2466d0fbb7f4359b9bc980464a5aa26.xml |
| independent | mixed\_values | 通过 | evidence/538ece5cbc85437183c97093bbd60dab/0154f456f1cc4e63beff3860e0c62197.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/4e8f8cabe4be4bc597c340c9dc291f55/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/fabccbb8e44c46bc87c2a2f9b2b9a35e/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/397e2667f8844d40952a3d720d069b88/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/7d8c56a9caef4cc58b39bc0e96adafd4/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/3cd02467ff1241af8ffe60f3b9f85661/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-a0b80d7817204b8e9e0f69fd5614022d.xml --timeout 120.000000 | exited | 8 | logs/1676e7e1c5964a378abddf59a5d27e03/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-a0b80d7817204b8e9e0f69fd5614022d.xml | exited | 0 | logs/ec23da4fba6a446294fc7663f45cc2db/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-5d5905fb2d74482994cdc7992364286c.xml --timeout 120.000000 | exited | 0 | logs/be025120d6b9482089eb9f67b214d9f9/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-5d5905fb2d74482994cdc7992364286c.xml | exited | 0 | logs/05878f5832de4c1d900907e637078dc2/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-5b7014be52834d34b3c30e896bc774f2.xml --timeout 120.000000 | exited | 0 | logs/3fe8d488a2114587967d31a5add8503d/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-5b7014be52834d34b3c30e896bc774f2.xml | exited | 0 | logs/17aa63d8ff68487fada38d58d6fc76f8/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-89594a560bf04f07949838114f92411f.xml --timeout 120.000000 | exited | 0 | logs/36656b5e3e344837a6e72ced1bbab4ac/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/caba0dda00be4109a575f8426a7ccf53-89594a560bf04f07949838114f92411f.xml | exited | 0 | logs/eb4bbad4da2b40258ef4762e701a5e47/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/90af42f365c64772b06207e0db8a8061/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/6717c86cb4b14c58861beaf91f051e34/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/a3d129c725d7411c9f2b208b949ae626/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/1200c242807241abbdfcb575ca080f5f/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/3c521de6f829415da44d4da3d7ad46cf/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-30a0ffa345c049a0b33126edd1c3bb91.xml --timeout 120.000000 | exited | 0 | logs/3801354472104e5bb7b79b1a89a223af/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-30a0ffa345c049a0b33126edd1c3bb91.xml | exited | 0 | logs/992cbde9884e47a48fb1f2ba354b0431/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-6249c164fb2d48dea7f89b9aeb6320b5.xml --timeout 120.000000 | exited | 0 | logs/10942aa579374618b051b0f69af768a8/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-6249c164fb2d48dea7f89b9aeb6320b5.xml | exited | 0 | logs/09f5574c67e24bf69bf8adde3551ce38/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-f2466d0fbb7f4359b9bc980464a5aa26.xml --timeout 120.000000 | exited | 8 | logs/efa51e7324f4431fa94cef6f57fd22b7/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-f2466d0fbb7f4359b9bc980464a5aa26.xml | exited | 0 | logs/b67154266f784594a8f7bf8ce9bf51b8/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-0154f456f1cc4e63beff3860e0c62197.xml --timeout 120.000000 | exited | 0 | logs/69ec7992cf464d03a89bb976919940c5/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/538ece5cbc85437183c97093bbd60dab-0154f456f1cc4e63beff3860e0c62197.xml | exited | 0 | logs/6327d5fcad184bd98bc40a636b15f3a9/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
