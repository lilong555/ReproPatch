# ReproPatch 8f9e6ae80c55476fa98d83aa9e656138

任务：stale-build-injection
入口：verify-patch
结局：**REJECTED**
原因：REGRESSION\_FAILED
执行引擎：none
模型：未知
Docker 隔离：是
基线 commit：59f31d6d29d0fc51eaeb08bf46e757c65022932e
镜像：sha256:500d13919a823b0673d645dfd22b242d6b4bf1069fab2b4efade2a5a27de2e41
耗时：8.466 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：73

外部来源标签（未认证）：stale-build-injection

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/5cc1f17042a44fbfa387b560920c8933/cc67fc79a7564f40806a28f6bd5c5222.xml |
| baseline | positive\_values | 通过 | evidence/5cc1f17042a44fbfa387b560920c8933/9ffa9610ddc2492b80082440870e74db.xml |
| baseline | empty\_values | 通过 | evidence/5cc1f17042a44fbfa387b560920c8933/b4eb306ed52440479f7b81edd5355e19.xml |
| baseline | mixed\_values | 通过 | evidence/5cc1f17042a44fbfa387b560920c8933/26441ede4ea24a63a7e320cd94f4d7b1.xml |
| independent | negative\_values | 通过 | evidence/3c860f77fc1b41b1bceb83340b6dfd77/0989d5183ace49f5b9f76d17b9518650.xml |
| independent | positive\_values | 通过 | evidence/3c860f77fc1b41b1bceb83340b6dfd77/58e311c5e7554b7598dc2c5deadcca41.xml |
| independent | empty\_values | 失败 | evidence/3c860f77fc1b41b1bceb83340b6dfd77/a07e98ed8d97486e8116c6c8acabaf4f.xml |
| independent | mixed\_values | 通过 | evidence/3c860f77fc1b41b1bceb83340b6dfd77/2357fa7379c94c3da86149acaf064a8e.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/281accac3868417c950ab4b4fb79adde/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/c29e845db51646c097a76580fb987ab6/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/b172521a917c4eacbcc650d23039500b/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/5064398a6dbb45d7b4e607224bcb549b/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/9d967755e9fd4ccdbd9f8791962e229f/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-cc67fc79a7564f40806a28f6bd5c5222.xml --timeout 120.000000 | exited | 8 | logs/a466954265ec446785fe9f341463fd2a/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-cc67fc79a7564f40806a28f6bd5c5222.xml | exited | 0 | logs/74e0cc1508d64f2596b094f687a5f7fb/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-9ffa9610ddc2492b80082440870e74db.xml --timeout 120.000000 | exited | 0 | logs/b3a2aa8a126d4044886ebb4a90d04365/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-9ffa9610ddc2492b80082440870e74db.xml | exited | 0 | logs/943a1e348bee4f2890059ac1f7530f12/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-b4eb306ed52440479f7b81edd5355e19.xml --timeout 120.000000 | exited | 0 | logs/6e54b033d1044e50bfa051d6f9660727/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-b4eb306ed52440479f7b81edd5355e19.xml | exited | 0 | logs/aeb5b27e27a748c1b7b25b1dfcb466bd/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-26441ede4ea24a63a7e320cd94f4d7b1.xml --timeout 120.000000 | exited | 0 | logs/c6c1d2864ea045b889d77f74dc1f42a5/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/5cc1f17042a44fbfa387b560920c8933-26441ede4ea24a63a7e320cd94f4d7b1.xml | exited | 0 | logs/a4cd11303a954a129bfd1490f4cbcf92/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/a49cf68b97f843f08c988a0a970b0b36/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/7a0c5d2fa9de46839282093b57a74b11/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/01047975b8b94b73af3ba676dda46647/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/d37f622017fe4f40a22d59573daf7ec5/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/5e34829cd3004c068a81547d2afb7d32/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-0989d5183ace49f5b9f76d17b9518650.xml --timeout 120.000000 | exited | 0 | logs/30f44dac78f84748808b8e3f9cdc521c/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-0989d5183ace49f5b9f76d17b9518650.xml | exited | 0 | logs/c8fe42db2d8b447aa973793aa7317a42/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-58e311c5e7554b7598dc2c5deadcca41.xml --timeout 120.000000 | exited | 0 | logs/c178fadf22b74854901b61dcb24f9cbf/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-58e311c5e7554b7598dc2c5deadcca41.xml | exited | 0 | logs/cdf2c01e8ce942b4af11be00dba7a0aa/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-a07e98ed8d97486e8116c6c8acabaf4f.xml --timeout 120.000000 | exited | 8 | logs/641a51a955b0408eaa8858f5f9d2fb3c/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-a07e98ed8d97486e8116c6c8acabaf4f.xml | exited | 0 | logs/7851eb0eed694a2db43f73b71e67f023/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-2357fa7379c94c3da86149acaf064a8e.xml --timeout 120.000000 | exited | 0 | logs/526bab03dc3e4ba3b9064e6f0ca8dde2/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/3c860f77fc1b41b1bceb83340b6dfd77-2357fa7379c94c3da86149acaf064a8e.xml | exited | 0 | logs/58dd30640f324dc2a486c76fdcdee95a/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
