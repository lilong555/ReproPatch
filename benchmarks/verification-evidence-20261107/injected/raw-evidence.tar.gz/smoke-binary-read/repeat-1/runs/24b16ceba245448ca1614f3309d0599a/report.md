# ReproPatch 24b16ceba245448ca1614f3309d0599a

任务：stale-build-injection
入口：verify-patch
结局：**REJECTED**
原因：REGRESSION\_FAILED
执行引擎：none
模型：未知
Docker 隔离：是
基线 commit：59f31d6d29d0fc51eaeb08bf46e757c65022932e
镜像：sha256:500d13919a823b0673d645dfd22b242d6b4bf1069fab2b4efade2a5a27de2e41
耗时：10.170 秒
模型步骤：0；准入工具：0
模型停止原因：未知
HTTP 请求次数：0
Token 输入 / 输出 / 合计：未知 / 未知 / 未知
合成用量：否；费用：未知
执行清理确认：是
产物完整：是
事件截止序号：73

外部来源标签（未认证）：stale-build-injection

| 评估 | 测试 | 观察 | 证据 |
| --- | --- | --- | --- |
| baseline | negative\_values | 失败 | evidence/afab111888d341dcae656c7732e16bd1/6a4a978eae3347a0ad1e85dcb831efbc.xml |
| baseline | positive\_values | 通过 | evidence/afab111888d341dcae656c7732e16bd1/ff983480884d4b6ba98d7370d0b7be4e.xml |
| baseline | empty\_values | 通过 | evidence/afab111888d341dcae656c7732e16bd1/7f7707c513dd4236834e02d5495c9312.xml |
| baseline | mixed\_values | 通过 | evidence/afab111888d341dcae656c7732e16bd1/afad4f5599f24158a242bee4f6562528.xml |
| independent | negative\_values | 通过 | evidence/fdc3e5caff83480c9b5a73ce23cd3139/4155fd4a739b4f278e2c16e1d35fa138.xml |
| independent | positive\_values | 通过 | evidence/fdc3e5caff83480c9b5a73ce23cd3139/7d370f7e956043eaaa13a580def264d3.xml |
| independent | empty\_values | 失败 | evidence/fdc3e5caff83480c9b5a73ce23cd3139/007940eda9774b44acc6002f6450688c.xml |
| independent | mixed\_values | 通过 | evidence/fdc3e5caff83480c9b5a73ce23cd3139/9fc856efce0d4046963d8809b2624b38.xml |

| 评估 | 命令 | 状态 | 退出码 | stderr |
| --- | --- | --- | ---: | --- |
| baseline | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/ededdfaf21714be49b60a43dce587e0f/stderr.bin |
| baseline | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/15ccf271c24243648d9c14b4e0f744f7/stderr.bin |
| baseline | cmake --build /build --parallel 2 | exited | 0 | logs/d6630c0aa5c64e0da99d583a4e60d1a2/stderr.bin |
| baseline | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/7f906652e4e4432aa5a9cd64e1d5f4f4/stderr.bin |
| baseline | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/e682ef06497e4e82bf2fbae54181fb75/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-6a4a978eae3347a0ad1e85dcb831efbc.xml --timeout 120.000000 | exited | 8 | logs/7086df3da5094d89b119206ab0717eda/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-6a4a978eae3347a0ad1e85dcb831efbc.xml | exited | 0 | logs/e8daf056e1ad410e9f7534f6f4cc414a/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-ff983480884d4b6ba98d7370d0b7be4e.xml --timeout 120.000000 | exited | 0 | logs/66f66d6fa8e6423cbf81b8a832408c47/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-ff983480884d4b6ba98d7370d0b7be4e.xml | exited | 0 | logs/3175e8b3460842c297c7566800f2374c/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-7f7707c513dd4236834e02d5495c9312.xml --timeout 120.000000 | exited | 0 | logs/6a617aa0d94641f18fab4722abace7e1/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-7f7707c513dd4236834e02d5495c9312.xml | exited | 0 | logs/1dfec815e24c4d09a40de5f539a80e4a/stderr.bin |
| baseline | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-afad4f5599f24158a242bee4f6562528.xml --timeout 120.000000 | exited | 0 | logs/79106dae2b3d45839837f43e2f2c9480/stderr.bin |
| baseline | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/afab111888d341dcae656c7732e16bd1-afad4f5599f24158a242bee4f6562528.xml | exited | 0 | logs/3e598e54455a4349b8473af5906fd0f6/stderr.bin |
| independent | /bin/sh -ec command -v cmake; command -v ctest; command -v c++; command -v cat; command -v timeout; /usr/bin/sleep --version; cmake --version; ctest --version; printf &\#x27;\\nREPROPATCH\_CXX\_VERSION\\n&\#x27;; c++ --version | exited | 0 | logs/458f52f16f7f48b6a4faaabb0a6b9bdc/stderr.bin |
| independent | cmake -S /src -B /build -DCMAKE\_BUILD\_TYPE=Debug | exited | 0 | logs/1327cb1c55e141a5be84c045d8e39397/stderr.bin |
| independent | cmake --build /build --parallel 2 | exited | 0 | logs/34e7d2fe8a624251b9d6d67d762bf2b0/stderr.bin |
| independent | ctest --test-dir /build --show-only=json-v1 | exited | 0 | logs/c899903c28a34917be39f507313ebe55/stderr.bin |
| independent | /bin/sh -ec test \! -L /build/.repropatch-results &amp;&amp; mkdir -p -- /build/.repropatch-results | exited | 0 | logs/8d9a36ea639440b2809f0d1fd245d5dc/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^negative\_values$ --output-junit /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-4155fd4a739b4f278e2c16e1d35fa138.xml --timeout 120.000000 | exited | 0 | logs/d89c47e25a3642178a71c4ce9a1cf5c4/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-4155fd4a739b4f278e2c16e1d35fa138.xml | exited | 0 | logs/ec6fd916464c4702bec34c3bdc105d71/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^positive\_values$ --output-junit /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-7d370f7e956043eaaa13a580def264d3.xml --timeout 120.000000 | exited | 0 | logs/e6d40c335f204e94b973ae4d3da21b59/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-7d370f7e956043eaaa13a580def264d3.xml | exited | 0 | logs/25eb9798c55d475ab53e2d9631d4a075/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^empty\_values$ --output-junit /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-007940eda9774b44acc6002f6450688c.xml --timeout 120.000000 | exited | 8 | logs/25e3578b96074016af7b2af507768bef/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-007940eda9774b44acc6002f6450688c.xml | exited | 0 | logs/2d8092e9ace643ebac60db95b7513a8e/stderr.bin |
| independent | ctest --test-dir /build --output-on-failure --no-tests=error -R ^mixed\_values$ --output-junit /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-9fc856efce0d4046963d8809b2624b38.xml --timeout 120.000000 | exited | 0 | logs/998be51cbc32490d8add555ef3ec7ee5/stderr.bin |
| independent | /bin/sh -ec test -f &quot;$1&quot; &amp;&amp; test \! -L &quot;$1&quot; &amp;&amp; test &quot;$\(wc -c &lt; &quot;$1&quot;\)&quot; -lt 4194304 &amp;&amp; cat -- &quot;$1&quot; repropatch-read /build/.repropatch-results/fdc3e5caff83480c9b5a73ce23cd3139-9fc856efce0d4046963d8809b2624b38.xml | exited | 0 | logs/5446046b92704c9cb694f94b691f3fc2/stderr.bin |

领域轨迹：events.jsonl

仅验收冻结 Task 的测试 oracle，不证明所有输入正确。
Docker 与宿主共享内核。
恢复仅支持已提交且关闭的完整输入边界；未知模型请求和历史工具不重做。
外部生成过程、预算和 trace 未受本次运行管理或验证。
