"""Checkpointed localization phase and exact model-visible source receipts."""

import json
import math
import time
from dataclasses import asdict

from .artifacts import EvidenceRef
from .errors import InfrastructureError, PolicyError
from .task import canonical_json

SCHEMA = "repropatch.localization.session.v1"
READ_ONLY_TOOLS = frozenset({"list_directory", "read_file", "search_code", "search_files"})


class LocalizationSession:
    def __init__(self, harness, workspace, toolbox, context_state):
        self.harness, self.workspace, self.toolbox = harness, workspace, toolbox
        self.context_state = context_state
        contract = {
            "mode": harness.localization_mode,
            "tool_budget": harness.localization_tool_budget,
            "step_budget": harness.localization_step_budget,
        }
        state = context_state.localization_state
        if state:
            if (
                state.get("schema") != SCHEMA
                or state.get("contract") != contract
                or state.get("phase") not in {"localization", "repair"}
                or type(state.get("started_elapsed_seconds")) not in (int, float)
                or not math.isfinite(state["started_elapsed_seconds"])
                or any(
                    type(state.get(key)) is not int or state[key] < 0
                    for key in ("tools_used", "model_steps", "tool_ordinal", "receipt_count")
                )
            ):
                raise InfrastructureError("LOCALIZATION_STATE: checkpoint identity mismatch")
        else:
            state.update(
                schema=SCHEMA,
                contract=contract,
                phase="localization" if contract["tool_budget"] else "repair",
                tools_used=0,
                model_steps=0,
                tool_ordinal=0,
                receipt_count=0,
                baseline_recorded=False,
                source_tree_sha256=workspace.expected_manifest.sha256,
                started_elapsed_seconds=time.monotonic() - harness.context.clock.started,
            )
        self.state = state
        self.engine = None
        if contract["mode"] != "native":
            from .localization import Localization

            self.engine = Localization(toolbox, mode=contract["mode"], state=state.get("engine"))
        self._sync()

    @property
    def phase(self):
        return self.state["phase"]

    def _sync(self):
        if self.engine is not None:
            self.state["engine"] = self.engine.to_dict()
        self.context_state.localization_state = self.state
        self.harness.report["localization"] = self.state

    def progress(self):
        return {
            "phase": self.phase,
            "mode": self.state["contract"]["mode"],
            "localization_tool_calls_remaining": max(
                0, self.state["contract"]["tool_budget"] - self.state["tools_used"]
            ),
            "localization_model_steps_remaining": max(
                0, self.state["contract"]["step_budget"] - self.state["model_steps"]
            ),
        }

    def start_model(self):
        if self.phase == "localization":
            self.state["model_steps"] += 1
        self._sync()

    def exhausted(self):
        if self.phase != "localization":
            return None
        if self.state["tools_used"] >= self.state["contract"]["tool_budget"]:
            return "tool_budget"
        if self.state["model_steps"] >= self.state["contract"]["step_budget"]:
            return "model_step_budget"
        return None

    def transition(self, reason):
        if self.phase != "localization":
            return None
        self.state["phase"] = "repair"
        self.state["transition_reason"] = reason
        self.harness.log.emit(
            "localization_phase_finished",
            {
                "schema": SCHEMA,
                "reason": reason,
                "localization_tools_used": self.state["tools_used"],
                "localization_model_steps": self.state["model_steps"],
                "model_step": self.harness.report["model_steps"],
                "tool_calls_used": self.harness.report["tool_calls"],
                "cumulative_usage": self.harness.report["usage"],
                "elapsed_seconds": self.elapsed(),
                "source_tree_sha256": self.workspace.expected_manifest.sha256,
            },
        )
        self._sync()
        return {
            "role": "user",
            "content": (
                "The read-only localization phase is complete. Continue repairing from the "
                "observed source and baseline. Editing and command execution are now available. "
                "The original cumulative request, tool and time budgets remain in force."
            ),
        }

    def before_tool(self, name):
        self.state["tool_ordinal"] += 1
        if self.phase == "localization":
            self.state["tools_used"] += 1
            self._sync()
            if self.workspace.expected_manifest.sha256 != self.state["source_tree_sha256"]:
                raise InfrastructureError("LOCALIZATION_SOURCE_CHANGED: read-only snapshot changed")
            if self.state["tools_used"] > self.state["contract"]["tool_budget"]:
                raise PolicyError("LOCALIZATION_BUDGET: await the repair phase announcement")
            if name not in READ_ONLY_TOOLS:
                raise PolicyError("LOCALIZATION_READ_ONLY: inspect source before the repair phase")

    def elapsed(self):
        return max(
            0.0,
            time.monotonic()
            - self.harness.context.clock.started
            - self.state["started_elapsed_seconds"],
        )

    def delivered(self, name, arguments, text, *, tool_id, source_tree_sha256=None):
        manifest = self.workspace.expected_manifest
        source = source_tree_sha256 or manifest.sha256
        reference = EvidenceRef.save(
            self.harness.directory,
            f"agent/delivered/{tool_id}.json",
            text.encode("utf-8"),
            budget=self.harness.resources.budget,
        )
        try:
            visible = json.loads(text)
        except (ValueError, TypeError):
            visible = {"visible_text": text}
        feedback = None
        if self.engine is not None:
            try:
                feedback = self.engine.observe(
                    name,
                    arguments,
                    visible,
                    receipt_id=tool_id,
                    source_tree_sha256=source,
                )
            except PolicyError as exc:
                feedback = {"registered": False, "reason": str(exc).split(":", 1)[0]}
        self.state["receipt_count"] += 1
        report = self.harness.report
        self.harness.log.emit(
            "localization_exposure",
            {
                "schema": "repropatch.localization.exposure.v1",
                "phase": self.phase,
                "tool_name": name,
                "tool_call_id": tool_id,
                "model_step": report["model_steps"],
                "tool_calls_used": report["tool_calls"],
                "tool_ordinal": self.state["tool_ordinal"],
                "localization_tools_used": self.state["tools_used"],
                "cumulative_usage": report["usage"],
                "elapsed_seconds": self.elapsed(),
                "source_tree_sha256": source,
                "source_files": {
                    item.path: item.sha256
                    for item in manifest.files
                    if item.path in self.toolbox.readable
                },
                "delivered_ref": asdict(reference),
                "feedback_registration": feedback,
            },
        )
        self._sync()

    def baseline(self, value):
        if self.state["baseline_recorded"]:
            return
        self.delivered(
            "baseline",
            {},
            canonical_json(value).decode("utf-8"),
            tool_id="baseline",
            source_tree_sha256=value.get("source_tree_sha256"),
        )
        self.state["baseline_recorded"] = True
        self._sync()
